# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.db.models import Avg, Max
from .models import SensorInfor,ThresholdVal
import serial
import RPi.GPIO as GPIO
import time
import MySQLdb
import plantwateringsystem
import subprocess
import sys

#Start Subprocess
subprocess.Popen([sys.executable, 'plantwateringsystem.py'], 
                                    stdout=subprocess.PIPE, 
                                    stderr=subprocess.STDOUT) 

def home(request):
    
    if(SensorInfor.objects.count()==0): #Check if database table is empty
        context = {
            'temp':"N/A",
            'humidity':"N/A",
            'SoilM':"N/A",
            'Sunlight':"N/A",
            'DateAdded' :"N/A"
        }
    else:
        info = SensorInfor.objects.latest('sensorID') # Get latest database entry
        
        #Lines below are for determining average sensor data values based on historical data
        meanTemp = SensorInfor.objects.all().aggregate(Avg('temperature')).get('temperature__avg')
        meanHum = SensorInfor.objects.all().aggregate(Avg('humidity')).get('humidity__avg')
        meanSoil = SensorInfor.objects.all().aggregate(Avg('SoilMoisture')).get('SoilMoisture__avg')
        meanSun = SensorInfor.objects.all().aggregate(Avg('Sunlight')).get('Sunlight__avg')
        
        ThresVal = ThresholdVal.objects.get(thresholdID=1)
        
        context = { #add into dictionary to be returned to dashboard page
            'temp':info.temperature,
            'humidity':info.humidity,
            'SoilM':info.SoilMoisture,
            'Sunlight':info.Sunlight,
            'DateAdded' : info.datetimestamp,
            'MeanTemp' : round(meanTemp,2),
            'MeanHum' : round(meanHum,2),
            'MeanSoil' : round(meanSoil,2),
            'MeanSun' : round(meanSun,2),
            'TempThres' : ThresVal.tempThresVal,
            'SunThres' : ThresVal.sunThresVal,
            'SoilThres' : ThresVal.soilThresVal,
            
        }
    
    
      
    return render(request, 'dashboard/index.html',context)


def water_plant(request):
    plantwateringsystem.water_command()
    return redirect('dashboard')

def open_shade(request): #Button to trigger shade opening
    plantwateringsystem.open_shade_command()
    return redirect('dashboard')

def close_shade(request):#Button to trigger shade closing
    plantwateringsystem.close_shade_command()
    return redirect('dashboard')

def change_thresholds(request):
    
    if request.method == 'POST':
        sunThres = ThresholdVal.objects.get(thresholdID=1)
        sunThres.tempThresVal = int(request.POST.get('Newtemp',''))
        sunThres.sunThresVal = int(request.POST.get('Newsun',''))
        sunThres.soilThresVal = int(request.POST.get('Newsoil',''))
        sunThres.save()
    return redirect('dashboard')
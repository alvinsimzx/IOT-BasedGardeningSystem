from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='dashboard'),
    path('water_plant',views.water_plant, name='waterplant'),
    path('open_shade',views.open_shade, name='openshade'),
    path('close_shade',views.close_shade, name='closeshade'),
    path('change_thres',views.change_thresholds, name='changethres')
]
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class SensorInfor(models.Model):
    sensorID = models.IntegerField(primary_key=True)
    temperature = models.TextField()
    humidity = models.TextField()
    SoilMoisture = models.TextField()
    Sunlight = models.TextField()
    datetimestamp = models.DateTimeField()
    
    def __str__(self):
        return self.sensorID

    class Meta:
        db_table = "sensorInfor"

class ThresholdVal(models.Model):
    thresholdID = models.IntegerField(primary_key=True)
    tempThresVal = models.IntegerField()
    sunThresVal = models.IntegerField()
    soilThresVal = models.IntegerField()
    
    def __str__(self):
        return self.thresholdID

    class Meta:
        db_table = "thresholdVal"